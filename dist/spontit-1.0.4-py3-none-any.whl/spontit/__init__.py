from spontit.resource import SpontitResource
